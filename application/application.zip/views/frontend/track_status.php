<div class="h-slider">
  <div class="container">
  <div class="hs-content">  
    <h3>Track Applicatiin Status</h3>
    <h2> Enter your Reference and Passport Number</h2>
  </div>
  
  <div class="search-panel">
   <form action="" method="post" >
	<div class="row">	  
	  <div class="col-sm-5 col-xs-6"> 
		<input type="text" placeholder="Enter Reference Number" />
	  </div>
      
	  <div class="col-sm-5 col-xs-6"> 
		<input type="text" placeholder="Enter Passport Number" />
	  </div>
	  
	  <div class="col-sm-2 col-xs-12"> 		
		<input type="submit" value="Track" />
	  </div>
      
	</div>
    </form>
    
    
  </div>
  </div>  
</div>


<div class="container">
  <h1>Status Details<span></span></h1>
 <h6>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras eget pharetra lorem. Quisque nec erat felis. Nulla nunc nisl, pretium quis imperdiet quis, scelerisque et felis. Sed fermentum, tellus quis pulvinar tincidunt, mauris turpis porttitor tortor, ac cursus nibh ipsum quis metus. Aliquam erat volutpat. Aliquam eu sagittis nisi, sed finibus odio. Proin placerat, odio nec scelerisque tincidunt, mauris risus efficitur augue, nec efficitur metus nunc non sapien. Mauris accumsan lobortis nisl. Vestibulum fermentum facilisis urna, sed sollicitudin est rhoncus ac.</h6>
</div>
