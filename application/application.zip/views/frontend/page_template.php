<div class="inner-banner">
  <div class="container">
    <h2>
      <?=$title?>
    </h2>
  </div>
</div>
<div class="container">
  <h1><?=$title?><span></span></h1>
  <p>&nbsp;</p>
  <?=$page_content?>
  <p>&nbsp;</p>
</div>
