<div class="inner-banner">
  <div class="container">
    <h2>
      <?=$title?>
    </h2>
  </div>
</div>
<div class="container">
  <h1><?=$title?><span></span></h1>
  
  <div class="row">
  <div class="col-md-4">
  <div class="my-ac">
  <i class="fa fa-user" aria-hidden="true"></i><br />
  <h3>Mr. ABC Smith</h3>
  </div>
  </div>
  
  <div class="col-md-4">
  <div class="my-ac">
  <i class="fa fa-mobile" aria-hidden="true"></i><br />
  <h3>+1-98765433</h3>
  </div>
  </div>
  
  <div class="col-md-4">
  <div class="my-ac">
  <i class="fa fa-envelope-o" aria-hidden="true"></i><br />
  <h3>abcsmith1032@yahoo.com</h3>
  </div>
  </div>
  
  
  </div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
