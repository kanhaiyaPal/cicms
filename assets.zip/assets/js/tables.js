$(document).ready(function() {
		$('#pages_table').dataTable();
} );